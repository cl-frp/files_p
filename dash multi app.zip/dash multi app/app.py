import dash

external_stylesheets = ['https://codepen.io/chriddyp/pen/bWLwgP.css']

app = dash.Dash(__name__, external_stylesheets=external_stylesheets)


#app = dash.Dash(__name__, suppress_callback_exceptions=True)
#app = dash.Dash(__name__)
#server = app.server

