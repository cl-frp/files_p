import dash_core_components as dcc
import dash_html_components as html
from dash.dependencies import Input, Output

import socket

import os

MAIN_DIR = 'C:/Python/dash multi app'
APPs_DIR = 'C:/Python/dash multi app/apps'

import sys
sys.path.insert(0, APPs_DIR)
sys.path.insert(0, MAIN_DIR)

from app import app
from apps import hourly_costs_app, app2, hourly_costs_app2#, app2, hourly_costs_app,

os.chdir(MAIN_DIR)

app.layout = html.Div([
    dcc.Location(id='url', refresh=False),
    html.Div(id='page-content')
])


@app.callback(Output('page-content', 'children'),
              Input('url', 'pathname'))


def display_page(pathname):
    if pathname == '/apps/hourly_costs':
        return hourly_costs_app.layout
    if pathname == '/apps/app2':
        return app2.layout
    elif pathname == '/apps/hourly_costs2':
        return hourly_costs_app2.layout

if __name__ == '__main__':
    app.run_server()