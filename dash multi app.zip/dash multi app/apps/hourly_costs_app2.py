import dash_core_components as dcc
import dash_html_components as html
from dash.dependencies import Input, Output


import pandas as pd
import numpy as np
import datetime as dt
from datetime import timedelta
from datetime import date

import plotly.express as px
import plotly.graph_objects as go

import os

MAIN_DIR = 'C:/Python/dash multi app'
APPs_DIR = 'C:/Python/dash multi app/apps'

import sys
sys.path.insert(0, APPs_DIR)
sys.path.insert(0, MAIN_DIR)

from app import app

os.chdir(APPs_DIR)
hourly_costs_df = pd.read_csv('hourly_cost_fcst.csv')
os.chdir(MAIN_DIR)

def format_df(df):

    df['ValueDate'] = pd.to_datetime(df['ValueDate'])
    df.set_index('ValueDate', inplace = True)

    return df

hourly_costs_df = format_df(hourly_costs_df)

countries_options = np.unique(hourly_costs_df.columns).tolist()

rdi = dcc.RadioItems(id = 'radio_items',
                    options= [
                            {'label': 'Hourly', 'value': 'Hourly'},
                            {'label': 'Daily', 'value': 'Daily'},
                            {'label': 'Monthly', 'value': 'Monthly'}
                            ],
                    value = 'Daily'
                    )

dpr1 = dcc.DatePickerRange(
                            id='dpr1',
                            min_date_allowed = dt.date.today(),
                            max_date_allowed = date(2023, 1, 1),
                            initial_visible_month = dt.date.today(),
                            start_date = dt.date.today(),
                            end_date = date(2023, 1, 1)
                            )

layout = html.Div(
className = 'row',
children = [
    dcc.Link('Go to App 2', href='/apps/app2'),
    html.H1("Hourly costs by country"),
    dcc.Location(id='hourly_costs2'),
    rdi,
    dpr1,
    html.Div(children=[
        dcc.Graph(id = 'line-chart', style={'display': 'inline-block', 'width' : '100%'})
    ]),
    dcc.Checklist(
        id = 'country',
        options = [{
            'label' : i,
            'value' : i
        } for i in countries_options],
        value = [countries_options[0]]),
    html.Div(id='page-hourly_costs2')
])

def gen_traces(country, df, radio_item, start_date, end_date):

    df = df[(df.index >= start_date) & (df.index <= end_date)].copy()
    df_plot = df[country].copy()

    if radio_item == 'Daily':
        df_plot = df_plot.resample('1d').mean()
    elif radio_item == 'Monthly':
        df_plot = df_plot.resample('M').mean()

    df_plot = df_plot.sort_index()

    colors_list = px.colors.qualitative.Dark24
    color_i = 1
    traces = []

    for each_col in df_plot.columns:

        traces.append(go.Scatter(x = df_plot.index,
                        y = df_plot[each_col],
                        mode = 'lines',
                        line_color = colors_list[color_i],
                        name = str(each_col)

                        ))
        color_i = color_i + 1


    return traces

@app.callback(
    Output('line-chart', 'figure'),
    [Input('country', 'value'),
    Input('radio_items', 'value'),
    Input('dpr1', 'start_date'),
    Input('dpr1', 'end_date')
    ])


def update_graph(country, radio_item, start_date, end_date):

    return {
        'data': gen_traces(country, hourly_costs_df, radio_item, start_date, end_date),
        'layout':
        go.Layout(
            title='Hourly Costs')
    }


@app.callback(
    Output('page-hourly_costs2', 'children'),
    Input('country', 'value'))

def display_value(value):
    return 'You have selected "{}"'.format(value)